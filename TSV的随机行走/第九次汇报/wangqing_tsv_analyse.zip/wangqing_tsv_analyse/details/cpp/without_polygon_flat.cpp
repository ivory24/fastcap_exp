/*
*���볤���������Ϣ���γ�ƽ�壬��ȥ������Σ�������Ԫ�󣬽����������ļ��� 
*/
#include<iostream>
#include<fstream>
#include<vector>
#include<string.h>
#include<stdio.h>
#include<math.h>
using namespace std;

#define pi 3.141592653

double sq( double t )
{
	return t * t;
}
struct Node
{
	double x;
	double y;
	double z;
	void inval( double x1, double y1, double z1 )
	{
		x = x1; y = y1; z = z1;   	
	}
	Node move( double xx, double yy, double zz )
	{
		Node nn;
		nn.inval(x+xx,yy+y,zz+z);
		return nn;
	}
	Node up(double height)
	{
		Node nn;
		nn.inval(x,y,z+height);
		return nn;
	}
	double distance( Node noo)
	{
		return sqrt( sq( noo.x - x ) + sq( noo.y - y ) + sq( noo.z - z ));
	}
	Node() {};
};

FILE* fin;
int vn = 0,num = 0;
double length = 0.0, width = 0.0, height = 0.0;
double slen = 0.0, swid = 0.0, shei=0.0; 
double radius, theta, tv1,tv2;
int ln = 0, wn = 0,hn = 0;
string s;
Node* no = new Node[4];
Node* noPolygon; 

struct Quad
{
	Node qno[4];
	void inval( Node lt, Node rt, Node ru, Node lu )
	{
		qno[0] = lt;
		qno[1] = rt;
		qno[2] = ru;
		qno[3] = lu;
	}
	void move( Quad pred, double xh1, double yh1, double zh1,double xh2, double yh2, double zh2 )
	{
		qno[0]=pred.qno[3];
		qno[1]=pred.qno[2];
		qno[2]=pred.qno[2].move(xh2,yh2,zh2);
		qno[3]=pred.qno[3].move(xh1,yh1,zh1);
	}
	void move_ltor( Quad pred, double xh1, double yh1, double zh1,double xh2, double yh2, double zh2 )
	{
		qno[0]=pred.qno[0].move(xh1,yh1,zh1);
		qno[1]=pred.qno[0];
		qno[2]=pred.qno[3];
		qno[3]=pred.qno[3].move(xh2,yh2,zh2);
	}
	void every_point_move(Quad pred, double xx, double yy, double zz)
	{
		for(int j = 0; j< 4; j++)
		{
			qno[j].x = pred.qno[j].x+xx;
			qno[j].y = pred.qno[j].y+yy;
			qno[j].z = pred.qno[j].z+zz;
		}
	}
	void outfile()
	{
		fin = fopen( s.c_str(), "aw+" );
		fprintf( fin, "Q %d",num);
		for( int j = 0; j < 4; j++ )
		{
			fprintf( fin, "  %.3f %.3f %.3f", qno[j].x, qno[j].y, qno[j].z);
		}
		fprintf( fin, "\n" );
		fclose(fin);
	}
	void print()
	{
		for( int j = 0; j < 4; j++ )
		{
			printf( "  %.3f %.3f %.3f\n", qno[j].x, qno[j].y, qno[j].z);
		}
	}
};

vector<Quad> bQuad;
vector<Quad> sQuad;
vector<Quad> vsQuad;

void mesh_to_squad()
{
	//��Ҫ����sn�� 
	int sn; 
	Node tt0, tt1;
	Quad te,t1,t2;
	double xl = 0.0, yl=0.0,zl=0.0,x2 = 0.0, y2 =0.0, z2 = 0.0;
	for(int i = 0, n = bQuad.size(); i<n; i++)
	{
		te = bQuad[i];
		sn = (te.qno[3].distance(te.qno[0]))/slen;
		if(sn < 3)
		{
			sQuad.push_back(te);
			continue;
		}
		xl = (te.qno[3].x - te.qno[0].x)/sn;
		yl = (te.qno[3].y - te.qno[0].y)/sn;
		//zl = (te.qno[3].z - te.qno[0].z)/sn;
		x2 = (te.qno[2].x - te.qno[1].x)/sn;
		y2 = (te.qno[2].y - te.qno[1].y)/sn;
		//z2 = (te.qno[2].z - te.qno[1].z)/sn;
		t1.inval(te.qno[0],te.qno[1], te.qno[1].move(x2,y2,z2),te.qno[0].move(xl,yl,zl));
		sQuad.push_back(t1);
		for(int k = 0; k < sn-2; k++ )
		{
			t2.move(t1,xl,yl,zl,x2,y2,z2);
			sQuad.push_back(t2);
			t1 = t2;
			if( k == sn -3)
			{
				tt0 = t1.qno[3];
				tt1 = t1.qno[2];
			}
		}
		t1.inval(tt0,tt1, te.qno[2],te.qno[3]);
		sQuad.push_back(t1);
	}
}

void mesh_vsQuad()
{
	Node ts0, ts1;
	Quad te,t1,t2;
	int nn;
	double xl = 0.0, yl=0.0,zl=0.0,x2 = 0.0, y2 =0.0, z2 = 0.0;
	for(int i = 0, n = sQuad.size(); i<n; i++)
	{
		te = sQuad[i];
		nn = (te.qno[0].distance(te.qno[1]))/slen;
		if(nn < 3)
		{
			vsQuad.push_back(te);
			continue;
		}
		xl = (te.qno[0].x - te.qno[1].x)/nn;
		yl = (te.qno[0].y - te.qno[1].y)/nn;
		//zl = (te.qno[0].z - te.qno[1].z)/nn;
		x2 = (te.qno[3].x - te.qno[2].x)/nn;
		y2 = (te.qno[3].y - te.qno[2].y)/nn;
		//z2 = (te.qno[3].z - te.qno[2].z)/nn;
		t1.inval(te.qno[1].move(xl,yl,zl),te.qno[1],te.qno[2], te.qno[2].move(x2,y2,z2));
		vsQuad.push_back(t1);
		for(int k = 0; k < nn-2; k++ )
		{
			t2.move_ltor(t1,xl,yl,zl,x2,y2,z2);
			vsQuad.push_back(t2);
			t1 = t2;
			if( k == nn -3)
			{
				ts0 = t1.qno[1];
				ts1 = t1.qno[2];
			}
		}
		t1.inval(te.qno[0],ts0,ts1, te.qno[3]);
		vsQuad.push_back(t1);
	}
}
void input()
{
	cout << "Please input the length of cuboid: " <<endl;
	cin >> length;
	
	cout << "Please input the width of cuboid: "<<endl;
	cin >> width;
	
	cout << "Please input the number of regular polygon's vertices: " <<endl;
	cin >> vn;
	noPolygon = new Node[vn];
	
	cout << "Please input the sphere's radius: "<<endl;
	cin >> radius;
	theta = 360.0 /double(vn);
	
	cout << "Please input the  small length edge:" <<endl;
	cin >> slen;
	
	cout << "Please input the number of the conduct: " << endl;
	cin >> num;
	
	cout << "Please input the filename" <<endl;
	cin >> s;
}
int main()
{
	input();
	fin = fopen( s.c_str(), "aw+");
	if ( !fin )   
		return -1;
	fprintf( fin, "0 <%s>\n",s.c_str() );
	fprintf( fin, "#this is a  flat but polygon is deleted");
	fprintf( fin, "#length: %.3f width: %.3f\n", length, width);
	fprintf( fin, "#radius: %.3f small_edge_length: %.3f\n", radius, slen);
	fclose(fin);
	//����������ε����� 
	for(int i = 0; i < vn; i++)
	{
		tv1 = radius*cos((theta*i)/180*pi)+length/2.0;
		tv2 = radius*sin((theta*i)/180*pi)+width/2.0;
		noPolygon[i].inval(tv1,tv2,0.0);	
	}
	//�޴������ĸ����� 
	no[2].inval( 0.0, 0.0, 0.0 );
	no[3].inval(length, 0.0, 0.0);
	no[0].inval(length, (width - 2*radius)/2.0, 0.0); 
	no[1].inval(0.0, (width - 2*radius)/2.0, 0.0);
	//����˼·�ǣ��Ȼ���С���ı��Σ�Ȼ������з� 
	Quad temp;
	temp.inval(no[0],no[1],no[2],no[3]);
	bQuad.push_back(temp);
	no[2].inval( 0.0,(width - 2*radius)/2.0+radius*2, 0.0 );
	no[3].inval(length, (width - 2*radius)/2.0+radius*2, 0.0);
	no[0].inval(length, width, 0.0); 
	no[1].inval(0.0, width, 0.0);
	temp.inval(no[0],no[1],no[2],no[3]);
	bQuad.push_back(temp);
	for(int i = vn/4; i< (vn/4*3); i++)
	{
		no[1].inval(0.0,noPolygon[i+1].y, 0.0); 
		no[2].inval(0.0, noPolygon[i].y, 0.0);
		temp.inval( noPolygon[i+1], no[1], no[2], noPolygon[i]);
		bQuad.push_back(temp);
	}
	for(int i = 0; i< (vn/4); i++)
	{
		no[0].inval(length,noPolygon[i].y, 0.0); 
		no[3].inval(length, noPolygon[i+1].y, 0.0);
		temp.inval( no[0], noPolygon[i], noPolygon[i+1], no[3]);
		bQuad.push_back(temp);
	}
	for(int i = (vn/4*3); i< vn; i++)
	{
		no[0].inval(length,noPolygon[i].y, 0.0); 
		no[3].inval(length, noPolygon[(i+1)%vn].y, 0.0);
		temp.inval( no[0], noPolygon[i], noPolygon[(i+1)%vn], no[3]);
		bQuad.push_back(temp);
	}
	/*for( int i= 0, n = bQuad.size(); i<n; i++)
	{
		temp = bQuad[i];
		temp.outfile();
	}*/
	mesh_to_squad();
	mesh_vsQuad();
	for( int i= 0, n = vsQuad.size(); i<n; i++)
	{
		temp = vsQuad[i];
		temp.outfile();
	}
	return 0;
}

