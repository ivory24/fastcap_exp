/*
*���볤���ߵ������Ϣ���γ������壬������Ԫ�󣬽����������ļ��� 
*/
#include<iostream>
#include<fstream>
#include<vector>
#include<string.h>
#include<stdio.h>
#include<math.h>
using namespace std;

#define pi 3.141592653

double sq( double t )
{
	return t * t;
}
struct Node
{
	double x;
	double y;
	double z;
	void inval( double x1, double y1, double z1 )
	{
		x = x1; y = y1; z = z1;   	
	}
	Node move( double xx, double yy, double zz )
	{
		Node nn;
		nn.inval(x+xx,yy+y,zz+z);
		return nn;
	}
	Node up(double height)
	{
		Node nn;
		nn.inval(x,y,z+height);
		return nn;
	}
	double distance( Node noo)
	{
		return sqrt( sq( noo.x - x ) + sq( noo.y - y ) + sq( noo.z - z ));
	}
	Node() {};
};

FILE* fin;
int vn = 8,num;
double length = 0.0, width = 0.0, height = 0.0;
double slen = 0.0, swid = 0.0, shei=0.0; 
int ln = 0, wn = 0,hn = 0;
string s;
Node* no = new Node[8];

struct Quad
{
	Node qno[4];
	void inval( Node lt, Node rt, Node ru, Node lu )
	{
		qno[0] = lt;
		qno[1] = rt;
		qno[2] = ru;
		qno[3] = lu;
	}
	void move(Quad pred, double xx, double yy, double zz)
	{
		for(int j = 0; j< 4; j++)
		{
			qno[j].x = pred.qno[j].x+xx;
			qno[j].y = pred.qno[j].y+yy;
			qno[j].z = pred.qno[j].z+zz;
		}
	}
	void outfile()
	{
		fin = fopen( s.c_str(), "aw+" );
		fprintf( fin, "Q %d",num);
		for( int j = 0; j < 4; j++ )
		{
			fprintf( fin, "  %.3f %.3f %.3f", qno[j].x, qno[j].y, qno[j].z);
		}
		fprintf( fin, "\n" );
		fclose(fin);
	}
	void print()
	{
		for( int j = 0; j < 4; j++ )
		{
			printf( "  %.3f %.3f %.3f\n", qno[j].x, qno[j].y, qno[j].z);
		}
	}
};

vector<Quad> bQuad;
vector<Quad> sQuad;
vector<Quad> vsQuad;

void input()
{
	cout << "Please input the length of cuboid: " <<endl;
	cin >> length;
	
	cout << "Please input the width of cuboid: "<<endl;
	cin >> width;
	cout << "Please input the height of cuboid: "<<endl;
	cin >> height;
	cout << "Please input the  small length edge:" <<endl;
	cin >> slen;
	ln = (int)(length/slen);
	cout << "the num of length -----------------" << ln << endl;
	cout << "Please input the small width edge: " << endl;
	cin >> swid;
	wn = (int)(width/swid);
	cout << "the num of width -----------------" << wn << endl;
	cout << "Please input the small height edge: " <<endl;
	cin >> shei;
	hn = (int)(height/shei);
	cout << "the num of height -----------------" << hn << endl;
	cout << "Please input the number of the conduct: " << endl;
	cin >> num;
	cout << "Please input the filename" <<endl;
	cin >> s;
}
void meshqua( Quad sap, int n1, int n2)
{
	//n1----0:1   n2----0:3
	double x1 = ( sap.qno[1].x - sap. qno[0].x ) / n1;
	double y1 = ( sap.qno[1].y - sap. qno[0].y ) / n1;
	double z1 = ( sap.qno[1].z - sap. qno[0].z ) / n1;
	double x2 = ( sap.qno[3].x - sap. qno[0].x ) / n2;
	double y2 = ( sap.qno[3].y - sap. qno[0].y ) / n2;
	double z2 = ( sap.qno[3].z - sap. qno[0].z ) / n2;
	printf( "%.3f   %.3f   %.3f   %.3f   %.3f   %.3f\n" , x1, y1, z1, x2, y2, z2);
	Quad cor, me;													
	Node temn[3];
	temn[0].inval( sap.qno[0].x + x1, sap.qno[0].y + y1, sap.qno[0].z + z1 );
	temn[1].inval( sap.qno[0].x + x1 + x2, sap.qno[0].y + y1 + y2, sap.qno[0].z + z1 + z2 );
	temn[2].inval( sap.qno[0].x + x2, sap.qno[0].y + y2, sap.qno[0].z + z2 );
	cor.inval( sap.qno[0], temn[0], temn[1], temn[2] );
	cor.print();
	for( int r = 0; r < n1; r++ )
	{
		for ( int t=0; t < n2; t++ )
		{
			me.move ( cor, r * x1 + t * x2, r * y1 + t * y2, r * z1 + t * z2 );
			me.outfile();
		}
	}                                                                                                                                                                                                                                                                                                                                                                  
}

int main()
{
	input();
	fin = fopen( s.c_str(), "aw+");
	if ( !fin )   
		return -1;
	fprintf( fin, "0 <%s>\n",s.c_str() );
	fprintf( fin, "#this is a complete cuboid\n");
	fprintf( fin, "#length: %.3f width: %.3f height: %.3f\n", length, width, height);
	fprintf( fin, "#slen: %.3f swid: %.3f shei: %.3f\n", slen, swid, shei);
	fprintf( fin, "#ln: %d wn: %d hn: %d\n", ln, wn, hn);
	fclose(fin);
	no[0].inval( 0.0, 0.0, 0.0 );
	no[1].inval(length, 0.0, 0.0);
	no[2].inval(length, width, 0.0);
	no[3].inval(0.0, width, 0.0);
	no[4].inval(0.0, 0.0, height);
	no[5].inval(length, 0.0, height);
	no[6].inval(length, width, height);
	no[7].inval(0.0,width, height);
	Quad temp;
	temp.inval(no[0],no[1],no[5],no[4]);
	meshqua(temp, ln, hn);
	temp.inval(no[1],no[2],no[6],no[5]);
	meshqua(temp, wn, hn);
	temp.inval(no[2],no[3],no[7],no[6]);
	meshqua(temp, ln, hn);
	temp.inval(no[3],no[0],no[4],no[7]);
	meshqua(temp, wn, hn);
	temp.inval(no[4],no[5],no[6],no[7]);
	meshqua(temp, ln, wn);
	temp.inval(no[0],no[1],no[2],no[3]);
	meshqua(temp, ln, wn);
	return 0;
}

